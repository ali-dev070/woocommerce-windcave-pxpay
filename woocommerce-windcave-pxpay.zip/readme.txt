=== Your Plugin Name ===
 
Contributors: alidev070
Tags: Woocommerce Windcave Pxpay Payment Gateway
Requires at least: 6.3
Tested up to: 6.3.1
Stable tag: 1.0
License: GPLv3 or later License
License URI: http://
  
A WordPress plugin to use Windcave payment gateway pxpay in Woocommerce stores. 
  
== Description ==
  
This plugin is commercial version of our plugin that can help integrate Windcave Pxpay API to setup payment gateway in a Woocommerce store. 
  
== Installation ==
  
1. Upload the plugin folder to your /wp-content/plugins/ folder.
2. Go to the **Plugins** page and activate the plugin.
3. ...
  
== Frequently Asked Questions ==
  
= How do I use this plugin? =
  
Answer to the question
  
= How to uninstall the plugin? =
  
Simply deactivate and delete the plugin. 
  
== Screenshots ==
1. Activating plugin. 
2. Setting page in shipping section of Woocommerce. 
  
== Changelog ==
= 1.0 =
* Plugin not released yet. 